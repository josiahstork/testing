Six original transparent PNGs, eight independent room placements.
Read library-kit/metadata/clutter-pack.json for assets, transforms, supports, shadow rules and light pools.
Canvas 1536 x 1024. UV anchors include all transparent margins.
Each PNG is one rigid group; group members are not individually segmented.
The full room, lighting renderer and interactive preview are in library-kit.zip in the repository.
