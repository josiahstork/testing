Six original transparent PNGs, eight independent room placements.
Read library-kit/metadata/clutter-pack.json for transforms, supports, shadows, lights and material response.
Canvas 1536 x 1024. UV anchors include transparent margins.
Each PNG is one rigid group; members are not individually segmented.
Apply per-object material_response before shared room illumination to match the preview.
The full room renderer and preview are in library-kit.zip.
